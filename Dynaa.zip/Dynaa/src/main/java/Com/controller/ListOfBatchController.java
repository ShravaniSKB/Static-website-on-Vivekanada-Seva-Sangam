package Com.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/ListOfBatchController")
public class ListOfBatchController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ListOfBatchController() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("this is controler");
		BatchDao bdao=new BatchDao();
		
		List<Batchmodel> list=bdao.get_Batch_Details();
		
		System.out.println(list);
		request.setAttribute("Batchdata", list);
		RequestDispatcher rd=request.getRequestDispatcher("ListOfBatch.jsp");
		rd.include(request, response);
	}

}
