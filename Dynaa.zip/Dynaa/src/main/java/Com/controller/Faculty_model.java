package Com.controller;

public class Faculty_model {
	private int facultyId;
	private String firstname;
	private String lastname;

	private Long mobile;
	private String email;
	private String username;
	private String password;
	private String qualification;
	private int Experience;
	private String status;
	private int cid;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public Faculty_model(int facultyId, String firstname, String lastname, Long mobile, String email, String username,
			String password, String qualification, int experience, String status,int cid) {
		super();
		this.facultyId = facultyId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.mobile = mobile;
		this.email = email;
		this.username = username;
		this.password = password;
		this.qualification = qualification;
		this.Experience = experience;
		this.status = status;
		this.cid=cid;
	}
	public Faculty_model(int facultyId, String firstname, String lastname, Long mobile, String email, String username,
			String qualification, int experience, String status,int cid) {
		super();
		this.facultyId = facultyId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.mobile = mobile;
		this.email = email;
		this.username = username;
		this.qualification = qualification;
		this.Experience = experience;
		this.status = status;
		this.cid=cid;
	}
	
	public Faculty_model() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Faculty_model [facultyId=" + facultyId + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", mobile=" + mobile + ", email=" + email + ", username=" + username + ", password=" + password
				+ ", qualification=" + qualification + ", Experience=" + Experience + ", status=" + status + ", cid="
				+ cid + "]";
	}
	public int getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public int getExperience() {
		return Experience;
	}
	public void setExperience(int experience) {
		Experience = experience;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	

	
}
