package Com.controller;

public class Batchmodel {
	private int Bid;
	private String Bname;
	private String BStartdate;
	private int Cid;
	
	public int getBid() {
		return Bid;
	}
	public void setBid(int bid) {
		Bid = bid;
	}
	public String getBname() {
		return Bname;
	}
	public void setBname(String bname) {
		Bname = bname;
	}
	public String getBStartdate() {
		return BStartdate;
	}
	public void setBStartdate(String bStartdate) {
		BStartdate = bStartdate;
	}
	public int getCid() {
		return Cid;
	}
	public void setCid(int cid) {
		Cid = cid;
	}
	@Override
	public String toString() {
		return "Batchmodel [Bid=" + Bid + ", Bname=" + Bname + ", BStartdate=" + BStartdate + ", Cid=" + Cid + "]";
	}
	public Batchmodel(int bid, String bname, String bStartdate, int cid) {
		super();
		Bid = bid;
		Bname = bname;
		BStartdate = bStartdate;
		Cid = cid;
	}
	public Batchmodel() {
		super();
	}
	

}
