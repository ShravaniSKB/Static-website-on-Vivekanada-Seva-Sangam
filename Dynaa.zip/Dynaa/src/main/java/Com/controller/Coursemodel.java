package Com.controller;

public class Coursemodel {
	
	
	private int courseid;
	private String coursename;
	private String fee;
	private String duration;
	
	public Coursemodel() {}
		
		
	
	public Coursemodel(int a,String b,String c,String d ) {
		
		this.courseid=a;
		this.coursename=b;
		
		this.fee=c;
		this.duration=d;
	}



	@Override
	public String toString() {
		return "Coursemodel [courseid=" + courseid + ", coursename=" + coursename + ", fee=" + fee + ", duration="
				+ duration + "]";
	}



	public int getCourseid() {
		return courseid;
	}



	public void setCourseid(int i) {
		this.courseid = i;
	}



	public String getCoursename() {
		return coursename;
	}



	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}



	public String getFee() {
		return fee;
	}



	public void setFee(String fee) {
		this.fee = fee;
	}



	public String getDuration() {
		return duration;
	}



	public void setDuration(String duration) {
		this.duration = duration;
	}



	



	

}
