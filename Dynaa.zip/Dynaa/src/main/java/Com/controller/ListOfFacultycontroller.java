package Com.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/ListOfFacultycontroller")
public class ListOfFacultycontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public ListOfFacultycontroller() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Faculty_DAO fdao=new Faculty_DAO();
		
		List<Faculty_model> list=fdao.get_Faculty_Details();
		
		
		request.setAttribute("Facultydata", list);
		RequestDispatcher rd=request.getRequestDispatcher("ListOfFaculty.jsp");
		rd.include(request, response);
	}

}
