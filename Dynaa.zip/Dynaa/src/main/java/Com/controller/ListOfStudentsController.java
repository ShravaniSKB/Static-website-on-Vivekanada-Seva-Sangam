package Com.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ListOfStudentsController
 */
@WebServlet("/ListOfStudentsController")
public class ListOfStudentsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ListOfStudentsController() {
        // TODO Auto-generated constructor stub
    }
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi student controler list ");
		Studentdao sdao=new Studentdao();
		
		List<Studentmodel> list=sdao.get_Student_Details();
		
		
		request.setAttribute("Studentdata", list);
		RequestDispatcher rd=request.getRequestDispatcher("ListOfStudents.jsp");
		rd.include(request, response);
	}

}
