package Com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Faculty_DAO {
public String insert(Faculty_model Fm) {
  		
  		
  		
  		String status="failure";
  		
  	
  		try {
  			
  			Connection con = Dbconnection.connect();
  			
  			 PreparedStatement ps = con.prepareStatement("insert into Faculty(Ffname,Flname,Fmobileno,Fgmail,Fusername,Fpassword,Fqualification,Fyearsofexperience,Fstatus,cid) values(?,?,?,?,?,?,?,?,?,?)");
  			
  			 ps.setString(1, Fm.getFirstname());
  			 ps.setString(2, Fm.getLastname());
  			 ps.setLong(3, Fm.getMobile());
  			 ps.setString(4, Fm.getEmail());
  			 ps.setString(5, Fm.getUsername());
  			 ps.setString(6, Fm.getPassword());
  			 ps.setString(7, Fm.getQualification());
  			 ps.setInt(8, Fm.getExperience());
  			 ps.setString(9, Fm.getStatus());
  			 ps.setInt(10,Fm.getCid());
  			 

  			

  			 int n = ps.executeUpdate();
  			 
  			 if(n>0){
  				 status="SUCCESS";
  			 }
  		}
  		catch(Exception e) {
  			System.out.println(e);
  		}
  		
  		return status;
  	}
public List<Faculty_model> get_Faculty_Details() {
		List <Faculty_model> li=new ArrayList<>();	  		
	
		try {
			
			Connection con = Dbconnection.connect();
			
			 PreparedStatement ps = con.prepareStatement("select FacultyId,Ffname,Flname,Fmobileno,Fgmail,Fusername,Fqualification,Fyearsofexperience,FStatus,Cid from Faculty");
			 ResultSet rs = ps.executeQuery();
			  	 
			 while(rs.next()) {
			  				
			 int FacultyId = rs.getInt("FacultyId");
	  	     String Ffname = rs.getString("Ffname");
	  		 String Flname =rs.getString("Flname");
	  		 Long Fmobileno = rs.getLong("Fmobileno");
	  	     String Fgmail = rs.getString("Fgmail");
	  		 String Fusername =rs.getString("Fusername");
	  		 String Fqualification = rs.getString("Fqualification");
	  		 int Fyearsofexperience = rs.getInt("Fyearsofexperience");
	  		 String FStatus =rs.getString("FStatus");
	  		 int cid=rs.getInt("Cid");
	  		 li.add(new Faculty_model(FacultyId,Ffname,Flname,Fmobileno,Fgmail,Fusername,Fqualification,Fyearsofexperience,FStatus,cid));
			  			 }
			  		

		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return li;
	}
	
}
  



