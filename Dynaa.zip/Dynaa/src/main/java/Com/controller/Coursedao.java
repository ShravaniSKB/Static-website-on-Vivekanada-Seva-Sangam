package Com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Coursedao {

	public String insert(Coursemodel hi) {

		String status = "failure";

		try {

			Connection con = Dbconnection.connect();

			PreparedStatement ps = con.prepareStatement("insert into Course(Cname,Cfee,Cduration) values(?,?,?)");

			System.out.println("Adding Course name");
			ps.setString(1, hi.getCoursename());

			System.out.println("Adding Course fee");
			ps.setString(2, hi.getFee());

			System.out.println("Adding Course duration");
			ps.setString(3, hi.getDuration());

			int n = ps.executeUpdate();

			if (n > 0) {
				status = "SUCCESS";
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public List<Coursemodel> get_course_Details() {
	  		List <Coursemodel> li=new ArrayList<>();	  		
	  	
	  		try {
	  			
	  			Connection con = Dbconnection.connect();
	  			
	  			 PreparedStatement ps = con.prepareStatement("select * from course");
	  			 
	  			 ResultSet rs = ps.executeQuery();
	  	 
	  			 while(rs.next()) {
	  				
	  		 int cid = rs.getInt("Cid");
	  	   String cname = rs.getString("Cname");
	  		String cfee =rs.getString("Cfee");
	  		String duration = rs.getString("Cduration");
	  		 li.add(new Coursemodel(cid,cname,cfee,duration));
	  			 }
	  		}
	  		catch(Exception e) {
	  			System.out.println(e);
	  		}
	  		
	  		return li;
	  	}

}
