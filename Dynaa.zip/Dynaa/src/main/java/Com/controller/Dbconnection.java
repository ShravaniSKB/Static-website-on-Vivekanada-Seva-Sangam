package Com.controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbconnection {
	public static Connection connect() {
		Connection con=null;
		try {
			//loading the driver
			System.out.println("loading the driver");
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//connection establish
			System.out.println("Creating conection");
			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "9@gesairam");
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return con;
	}


}
