package Com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;


public class LoginDao {

	public String select(Loginmodel rs) {
		String status="failure";
		try {
			Connection con = Dbconnection.connect();

			String query = "select  Ausername,Apassword  from Admin  where Ausername=? && Apassword = ?";
					
		
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1,rs.getUsername());
			 ps.setString(2,rs.getPassword());
			ResultSet set = ps.executeQuery();
			
			while (set.next()) {
				System.out.println(set.getString(1));
				
				status="success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
		public Studentmodel select_student(Loginmodel Studen) {
			
			Studentmodel sm=null;
			try {
				Connection con = Dbconnection.connect();

				String query = "select  * from student  where Susername=? && SPassword = ?";
				
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1,Studen.getUsername());
				 ps.setString(2,Studen.getPassword());
				ResultSet set = ps.executeQuery();

				while(set.next()) {
						
					int id = set.getInt(1);
					String fname = set.getString(2);
					String lname = set.getString(3);
					long phone = set.getLong(4);
					String branch = set.getString(5);
					String gmail = set.getString(6);
					int yop = set.getInt(7);
					String username = set.getString(8);
					String password = set.getString(9);
					String  status= set.getString(10);
					int bid = set.getInt(11);
					String  gender= set.getString(12);
					sm=new Studentmodel(id, fname, username, lname, password,phone, gmail, branch, yop, gender, status, bid);
					
					
					System.out.println(sm+" student login details ");
				}
			} catch (Exception e) {
				System.out.println(e);
			}
			return sm;
		}
		public Faculty_model select_Faculty(Loginmodel lm) {
			Faculty_model fm=null;
			try {
				Connection con = Dbconnection.connect();

				String query = "select  * from Faculty  where Fusername=? && Fpassword = ?";
				
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1,lm.getUsername());
				 ps.setString(2,lm.getPassword());
				ResultSet set = ps.executeQuery();

				while(set.next()) {
						
					int FacultyId = set.getInt(1);
					String Ffname = set.getString(2);
					String Flname = set.getString(3);
					long Fmobileno = set.getLong(4);
					String Fgmail = set.getString(5);
					String Fusername = set.getString(6);
					String Fpassword = set.getString(7);
					String Fqualification = set.getString(8);
					int Fyearsofexperience = set.getInt(9);
					String  FStatus= set.getString(10);
					int cid = set.getInt(11);
					
					fm=new Faculty_model(FacultyId,Ffname,Flname,Fmobileno,Fgmail,Fusername,Fpassword,Fqualification,Fyearsofexperience,FStatus,cid);
					
					
					System.out.println(fm+" student login details ");
				}
			} catch (Exception e) {
				System.out.println(e);
			}
			return fm;
		}
	
			
			
}
