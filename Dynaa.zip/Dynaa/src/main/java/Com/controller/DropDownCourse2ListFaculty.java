package Com.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/DropDownCourse2ListFaculty")
public class DropDownCourse2ListFaculty extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DropDownCourse2ListFaculty() {
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("this is drop down course List for faculty");
		Coursedao cdao=new Coursedao();
		
		List<Coursemodel> list=cdao.get_course_Details();
		System.out.println("course "+ list);
		
		
		request.setAttribute("DropDownCoursedata1", list);
		RequestDispatcher rd=request.getRequestDispatcher("FacultyRegestration.jsp");
		rd.include(request, response);
			
	}

}
