package Com.controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Batchcontroller
 */
@WebServlet("/Batchcontroller")
public class Batchcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Hello");
		String Bname = request.getParameter("Bname");
		System.out.println(Bname);
		String BStartdate = request.getParameter("BStartdate");
		String c = request.getParameter("course");
		System.out.println(c);
		int course=Integer.parseInt(c);
		Batchmodel bm = new Batchmodel();
		bm.setBname(Bname);
		bm.setBStartdate(BStartdate);
		bm.setCid(course);
		BatchDao bd = new BatchDao();
		String status= bd.insert(bm);
		System.out.println(status);
		
		if(status=="SUCCESS") {
			RequestDispatcher rd12 = request.getRequestDispatcher("greeting1.jsp");
			rd12.include(request, response);
		}
		else {
			RequestDispatcher rd12 = request.getRequestDispatcher("Batchegister.jsp");
			rd12.include(request, response);
		}
	
	}

}
