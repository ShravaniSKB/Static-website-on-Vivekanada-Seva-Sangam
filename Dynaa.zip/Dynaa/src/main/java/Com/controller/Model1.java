package Com.controller;

public class Model1 {
	

	
		private String firstname;
		
		
		public Model1() {}
		public Model1(String fn) {
			this.firstname = fn;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
			System.out.println("Model data: "+this.firstname);
		}
		public String toString() {
			return "Hello" + this.firstname;
		}
	}

