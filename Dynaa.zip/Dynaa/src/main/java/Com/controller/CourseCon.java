package Com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CourseCon")
public class CourseCon extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		
		System.out.println("hii");
		String coursename = request.getParameter("coursename");
				System.out.println(coursename);

		String fee = request.getParameter("fee");
		String duration = request.getParameter("duration");
		
		Coursemodel cm = new Coursemodel();
//		cm.setCourseid(courseid);
		cm.setCoursename(coursename);
		cm.setDuration(duration);
		cm.setFee(fee);
		
		Coursedao cd= new Coursedao();
		
		String status= cd.insert(cm);
		System.out.println(status);
		
		if(status=="SUCCESS") {
			request.getRequestDispatcher("greeting.jsp").include(request, response);

		}
		else {
			request.getRequestDispatcher("CourseRegister.jsp").include(request, response);

		}
	}

}
