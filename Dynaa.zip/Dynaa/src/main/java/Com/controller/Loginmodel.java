package Com.controller;

public class Loginmodel {
	private String username;
	private String password;
	
	
	public Loginmodel() {}
	public Loginmodel(String us,String ps) {
		this.username = us;
		this.password=ps;
	}
	
	@Override
	public String toString() {
		return "Loginmodel [username=" + username + ", password=" + password + "]";
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
		System.out.println(this.username+" in DAO");
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
		System.out.println(this.password+" in DAO");
	}
	
	}


