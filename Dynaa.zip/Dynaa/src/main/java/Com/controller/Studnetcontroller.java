package Com.controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/Studentcontroller")
public class Studnetcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Student details is loading");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String username = request.getParameter("username");
		
		String Pwd = request.getParameter("pwd");
		Long Mobile = Long.parseLong(request.getParameter("mobile"));
		String Mail = request.getParameter("mail");
		String Branch = request.getParameter("branch");
		String p= request.getParameter("passedout");
		int Passedout = Integer.parseInt(p);
		String Status = request.getParameter("status");
		String b = request.getParameter("batch");
		int batch=Integer.parseInt(b);
		String Gender = request.getParameter("gender");
		
		
	Studentmodel obj = new Studentmodel();
		obj.setFirstname(firstname);
		obj.setUsername(username);
		obj.setLastname(lastname);
		obj.setPwd(Pwd);
		obj.setMobile(Mobile);
		obj.setMail(Mail);
		obj.setBranch(Branch);
		obj.setPassedout(Passedout);;
		obj.setStatus(Status);
		obj.setBid(batch);
		obj.setGender(Gender);
	

		
		Studentdao obj1 = new Studentdao();
		
		String status = obj1.insert(obj);
		System.out.println(status);

		if(status=="SUCCESS") {
		RequestDispatcher rd=request.getRequestDispatcher("greeting.jsp");
		rd.include(request, response);
		}
		else {
			RequestDispatcher rd=request.getRequestDispatcher("Studentregister.jsp");
			rd.include(request, response);
		}
		
	
		
		
	}

}