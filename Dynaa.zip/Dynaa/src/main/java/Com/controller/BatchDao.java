package Com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BatchDao {

	public String insert(Batchmodel he) {

		String status = "failure";

		try {

			Connection con = Dbconnection.connect();

			PreparedStatement ps = con.prepareStatement("insert into Batch(Bname,Bstartdate,cid) values(?,?,?)");

			ps.setString(1, he.getBname());

			ps.setString(2, he.getBStartdate());

			ps.setInt(3, he.getCid());

			int n = ps.executeUpdate();

			if (n > 0) {
				status = "SUCCESS";
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public List<Batchmodel> get_Batch_Details() {
		List<Batchmodel> li = new ArrayList<>();
		try {

			Connection con = Dbconnection.connect();

			PreparedStatement ps = con.prepareStatement("select Bid,Bname,BStartdate,Cid from batch");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int Bid = rs.getInt("Bid");
				String Bname = rs.getString("Bname");
				String BStartdate = rs.getString("BStartdate");
				int Cid = rs.getInt("Cid");
				li.add(new Batchmodel(Bid, Bname, BStartdate, Cid));
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		return li;
	}

	public Batchmodel getBatchbyBatchid(int id) {
		Batchmodel batch =null;
		try {

			Connection con = Dbconnection.connect();

			PreparedStatement ps = con.prepareStatement("select * from batch where Bid=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int Bid = rs.getInt("Bid");
				String Bname = rs.getString("Bname");
				String BStartdate = rs.getString("BStartdate");
				int Cid = rs.getInt("Cid");
				batch=new Batchmodel(Bid, Bname, BStartdate, Cid);
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		return batch;
	}
}
