package Com.controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Logincontrtoller
 */
@WebServlet("/Login")
public class Logincontrtoller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");

		String password = request.getParameter("password");
		String Role = request.getParameter("Roles");

			System.out.println(username);
			System.out.println(password);
			System.out.println(Role);
			
			
		Loginmodel lm = new Loginmodel();
		BatchDao list=new BatchDao();
		lm.setUsername(username);
		lm.setPassword(password);
		LoginDao ld = new LoginDao();
		
		

		if (Role.equals("1")) {
			String status=ld.select(lm);
			if(status.equals("success")) {
			RequestDispatcher rd12 = request.getRequestDispatcher("AdminHome.jsp");
			rd12.include(request, response);}
			else {
				RequestDispatcher rd12 = request.getRequestDispatcher("index.jsp");
				rd12.include(request, response);
			}
	
		}
		
		else if(Role.equals("2"))  {
//			String status=ld.select_student(lm);
			Studentmodel student = ld.select_student(lm);
			
			System.out.println(student+"   student details ");
				if(student!=null) {
					
					request.setAttribute("studentdetails", student);
				RequestDispatcher rd12 = request.getRequestDispatcher("Student.jsp");
				
				rd12.include(request, response);}
				else {
					RequestDispatcher rd12 = request.getRequestDispatcher("index.jsp");
					rd12.include(request, response);
				}
		}
		else if(Role.equals("3")) {
			Faculty_model faculty = ld.select_Faculty(lm);
			System.out.println(faculty+"   student details ");
			if(faculty!=null) {
				request.setAttribute("Facultydetails", faculty);
				RequestDispatcher rd12 = request.getRequestDispatcher("Faculty.jsp");
				rd12.include(request, response);}
			else {
				RequestDispatcher rd12 = request.getRequestDispatcher("index.jsp");
				rd12.include(request, response);
			}

		}
		
//		if (status.equals("success")) {
//			
//		} else {
//			javax.servlet.RequestDispatcher rd12 = request.getRequestDispatcher("LoginRegister.html");
//			rd12.include(request, response);
//		}

	}

}
