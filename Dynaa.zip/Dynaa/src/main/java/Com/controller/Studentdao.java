
package Com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Studentdao {


  	public String insert(Studentmodel hii) {
  		
  		String status="failure";
  		
  	
  		try {
  			
  			Connection con = Dbconnection.connect();
  			
  			 PreparedStatement ps = con.prepareStatement("insert into Student(Sfname,Slname,SmobileNo,Sbranch,Sgmail,SYearofPassout,Susername,SPassword,SStatus,Bid,Sgender) values(?,?,?,?,?,?,?,?,?,?,?)");
  			
  			 ps.setString(1, hii.getFirstname());

  			 ps.setString(2, hii.getLastname());
  			 ps.setLong(3, hii.getMobile());
  			 ps.setString(4, hii.getBranch());
  			 ps.setString(5, hii.getMail());
  			 ps.setInt(6, hii.getPassedout());
  			 ps.setString(7, hii.getUsername());
  			 ps.setString(8,hii.getPwd());
  			 ps.setString(9,hii.getStatus());
  			 ps.setInt(10,hii.getBid());
  			 ps.setString(11, hii.getGender());
  			
  			
  			

  		

  			 int n = ps.executeUpdate();
  			 
  			 if(n>0){
  				 status="SUCCESS";
  			 }
  		}
  		catch(Exception e) {
  			System.out.println(e);
  		}
  		
  		return status;
  	}
  	
	public List<Studentmodel> get_Student_Details() {
		List <Studentmodel> li=new ArrayList<>();	  		
		
		try {
			
			Connection con = Dbconnection.connect();
			
			 PreparedStatement ps = con.prepareStatement("select StudentId,Sfname,Slname,SmobileNo,Sbranch,Sgmail,SYearofPassout,Susername,SStatus,Sgender,Bid from Student");
			 ResultSet rs = ps.executeQuery();
			  	 
			 while(rs.next()) {
			  				
			 int StudentId = rs.getInt("StudentId");
	  	     String Sfname = rs.getString("Sfname");
	  		 String Slname =rs.getString("Slname");
	  		 Long SmobileNo = rs.getLong("SmobileNo");
	  	     String Sbranch = rs.getString("Sbranch");
	  		 String Sgmail =rs.getString("Sgmail");
	  		 int SYearofPassout = rs.getInt("SYearofPassout");
	  		 String Susername = rs.getString("Susername");
	  		 String SStatus =rs.getString("SStatus");
	  		String Sgender =rs.getString("Sgender");
	  		int  Bid =rs.getInt("Bid");
	  		 li.add(new Studentmodel(StudentId,Sfname,Slname,SmobileNo,Sbranch,Sgmail,SYearofPassout,Susername,SStatus,Sgender,Bid));
			  			 }
			  		

		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return li;
	}
}

