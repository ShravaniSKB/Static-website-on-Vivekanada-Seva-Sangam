package Com.controller;

public class Studentmodel {
	private int sid;
	
	private String firstname;
	private String username;
	private String lastname;
	private String  pwd;
	
	private Long mobile;
	private String  mail;
	private String branch;
	private int passedout;
	private String gender;	
	private String Status;
	private int Bid;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getPassedout() {
		return passedout;
	}
	public void setPassedout(int passedout) {
		this.passedout = passedout;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public int getBid() {
		return Bid;
	}
	public void setBid(int bid) {
		Bid = bid;
	}
	public Studentmodel(int sid, String firstname, String lastname, Long mobile,String branch, String mail,
			 int passedout, String username,  String status,String gender, int bid) {
		super();
		this.sid = sid;
		this.firstname = firstname;
		this.username = username;
		this.lastname = lastname;
		this.mobile = mobile;
		this.mail = mail;
		this.branch = branch;
		this.passedout = passedout;
		this.gender = gender;
		Status = status;
		Bid = bid;
	}
	
	
	public Studentmodel(int sid, String firstname, String username, String lastname, String pwd, Long mobile,
			String mail, String branch, int passedout, String gender, String status, int bid) {
		super();
		this.sid = sid;
		this.firstname = firstname;
		this.username = username;
		this.lastname = lastname;
		this.pwd = pwd;
		this.mobile = mobile;
		this.mail = mail;
		this.branch = branch;
		this.passedout = passedout;
		this.gender = gender;
		Status = status;
		Bid = bid;
	}
	public Studentmodel() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Studentmodel [sid=" + sid + ", firstname=" + firstname + ", username=" + username + ", lastname="
				+ lastname + ", pwd=" + pwd + ", mobile=" + mobile + ", mail=" + mail + ", branch=" + branch
				+ ", passedout=" + passedout + ", gender=" + gender + ", Status=" + Status + ", Bid=" + Bid + "]";
	}
	
	
	
}

