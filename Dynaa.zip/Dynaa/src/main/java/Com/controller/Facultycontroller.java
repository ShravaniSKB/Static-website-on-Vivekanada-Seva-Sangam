package Com.controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Facultycontroller")
public class Facultycontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
    public Facultycontroller() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Came");
		String fname = request.getParameter("firstname");
		String lname = request.getParameter("lastname");
		String m = request.getParameter("mobile");
		Long mobile=Long.parseLong(m);
		String email = request.getParameter("email");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String qualification = request.getParameter("qualification");
		String e = request.getParameter("Experience");
		int experiance=Integer.parseInt(e);
		String status = request.getParameter("status");
		String c = request.getParameter("course");
		int course=Integer.parseInt(c);
		Faculty_model Fm = new Faculty_model();
		Fm.setFirstname(fname);
		Fm.setLastname(lname);
		Fm.setMobile(mobile);
		Fm.setEmail(email);
		Fm.setUsername(username);
		Fm.setPassword(password);
		Fm.setQualification(qualification);
		Fm.setExperience(experiance);
		Fm.setStatus(status);;
		Fm.setCid(course);
		
		Faculty_DAO Fd = new Faculty_DAO();
		
		String Status= Fd.insert(Fm);
		System.out.println(Status);
		
		
		if(Status=="SUCCESS") {
			RequestDispatcher rd12 = request.getRequestDispatcher("greeting2.jsp");
			rd12.include(request, response);
		}
		else
		{
			RequestDispatcher rd12 = request.getRequestDispatcher("FacultyRegestration.jsp");
			rd12.include(request, response);
			

		}
		

		
	
		
	}

}
